from premailer import Premailer, transform

__version__ = '2.5.1'
