if __name__ == '__main__':
    from IPython.html import notebookapp as app
    app.launch_new_instance()
