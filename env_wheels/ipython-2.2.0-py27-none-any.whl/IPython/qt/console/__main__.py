if __name__ == '__main__':
    from IPython.qt.console import qtconsoleapp as app
    app.launch_new_instance()
