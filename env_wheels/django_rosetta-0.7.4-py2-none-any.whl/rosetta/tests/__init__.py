from .tests import *
from ..utils.microsofttranslator.test import *
