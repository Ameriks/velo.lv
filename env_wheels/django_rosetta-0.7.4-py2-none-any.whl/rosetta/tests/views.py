def dummy(request):
    pass

