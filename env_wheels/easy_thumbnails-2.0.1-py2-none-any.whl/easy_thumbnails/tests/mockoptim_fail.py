#!/usr/bin/env python
import sys
# This file does nothing except to mock a optimizer which does not work

print('Bad JPEG file')
sys.exit(1)
