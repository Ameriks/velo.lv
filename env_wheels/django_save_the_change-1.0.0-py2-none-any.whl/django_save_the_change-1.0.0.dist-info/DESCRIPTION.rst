Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Description: ###############
        Save The Change
        ###############
        
        .. image:: https://badge.fury.io/py/django-save-the-change.png
        	:target: http://badge.fury.io/py/django-save-the-change
        .. image:: https://travis-ci.org/karanlyons/django-save-the-change.png?branch=master
        	:target: https://travis-ci.org/karanlyons/django-save-the-change/
        .. image:: https://coveralls.io/repos/karanlyons/django-save-the-change/badge.png?branch=master
        	:target: https://coveralls.io/r/karanlyons/django-save-the-change
        
        Save The Change takes this:
        
        .. code-block:: pycon
        
        	>>> lancelot = Knight.objects.get(name="Sir Lancelot")
        	>>> lancelot.favorite_color = "Blue"
        	>>> lancelot.save()
        
        
        And does this:
        
        .. code-block:: sql
        
        	UPDATE "roundtable_knight"
        	SET "favorite_color" = 'Blue'
        
        
        Instead of this:
        
        .. code-block:: sql
        
        	UPDATE "roundtable_knight"
        	SET "name" = 'Sir Lancelot',
        	    "from" = 'Camelot',
        	    "quest" = 'To seek the Holy Grail.',
        	    "favorite_color" = 'Blue',
        	    "epithet" = 'The brave',
        	    "actor" = 'John Cleese',
        	    "full_name" = 'John Marwood Cleese',
        	    "height" = '6''11"',
        	    "birth_date" = '1939-10-27',
        	    "birth_union" = 'UK',
        	    "birth_country" = 'England',
        	    "birth_county" = 'Somerset',
        	    "birth_town" = 'Weston-Super-Mare',
        	    "facial_hair" = 'mustache',
        	    "graduated" = true,
        	    "university" = 'Cambridge University',
        	    "degree" = 'LL.B.',
        
        
        Installation
        ============
        
        Install Save The Change just like everything else:
        
        .. code-block:: bash
        
        	$ pip install django-save-the-change
        
        
        Documentation
        =============
        
        Full documentation is available at
        `ReadTheDocs <https://django-save-the-change.readthedocs.org/en/latest/>`_.
        
        
        History
        =======
        
        1.0.0 (09/08/2013)
        ------------------
        
         - Initial release.
        
Platform: UNKNOWN
Classifier: Development Status :: 5 - Production/Stable
Classifier: Intended Audience :: Developers
Classifier: Natural Language :: English
Classifier: License :: OSI Approved :: Apache Software License
Classifier: Programming Language :: Python
Classifier: Programming Language :: Python :: 2.6
Classifier: Programming Language :: Python :: 2.7
Classifier: Programming Language :: Python :: 3
Classifier: Programming Language :: Python :: 3.1
Classifier: Programming Language :: Python :: 3.2
Classifier: Programming Language :: Python :: 3.3
