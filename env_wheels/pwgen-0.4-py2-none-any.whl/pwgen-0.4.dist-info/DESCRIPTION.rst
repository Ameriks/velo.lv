Simple version of pwgen to generate random password or strings


